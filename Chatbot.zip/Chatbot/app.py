from flask import Flask, request, jsonify, render_template
import pickle
import json
from flask_cors import CORS  
from sklearn.feature_extraction.text import TfidfVectorizer

app = Flask(__name__)  # Flask will now look for templates automatically
CORS(app)  # Allow frontend to connect

# Load chatbot model and vectorizer
with open('model/chatbot_model.pkl', 'rb') as f:
    model = pickle.load(f)
with open('model/vectorizer.pkl', 'rb') as f:
    vectorizer = pickle.load(f)

# Load intents
with open('intents.json', 'r') as file:
    intents = json.load(file)

# Function to generate a response
def chatbot_response(user_input):
    input_text = vectorizer.transform([user_input])
    predicted_intent = model.predict(input_text)[0]

    for intent in intents['intents']:
        if intent['tag'] == predicted_intent:
            return intent['responses'][0]

    return "I'm not sure how to respond to that."

# ✅ Serve `index.html` from the `templates/` folder
@app.route('/')
def home():
    return render_template('index.html')  # Flask now finds it in `templates/`

# ✅ Chatbot API route
@app.route('/chat', methods=['POST'])
def chat():
    user_message = request.json.get("message")
    bot_reply = chatbot_response(user_message)
    return jsonify({"reply": bot_reply})

if __name__ == '__main__':
    app.run(debug=True)
