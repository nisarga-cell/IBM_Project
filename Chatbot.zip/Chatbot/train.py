import json
import random
import pickle
import os
import nltk
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression

# Load intents
with open('intents.json', 'r') as file:
    intents = json.load(file)

# Prepare dataset
text_data, labels = [], []
for intent in intents['intents']:
    for pattern in intent['patterns']:
        text_data.append(pattern)
        labels.append(intent['tag'])

# Convert text data to TF-IDF features
vectorizer = TfidfVectorizer()
X = vectorizer.fit_transform(text_data)
y = labels

# Train/test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train the model
model = LogisticRegression()
model.fit(X_train, y_train)

# Save model and vectorizer
if not os.path.exists('model'):
    os.makedirs('model')

with open('model/chatbot_model.pkl', 'wb') as f:
    pickle.dump(model, f)
with open('model/vectorizer.pkl', 'wb') as f:
    pickle.dump(vectorizer, f)

print("Training complete. Model saved!")
