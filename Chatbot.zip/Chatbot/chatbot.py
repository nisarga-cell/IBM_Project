import json
import pickle
import random
from sklearn.feature_extraction.text import TfidfVectorizer

# Load trained model and vectorizer
with open('model/chatbot_model.pkl', 'rb') as f:
    model = pickle.load(f)
with open('model/vectorizer.pkl', 'rb') as f:
    vectorizer = pickle.load(f)

# Load intents
with open('intents.json', 'r') as file:
    intents = json.load(file)

# Chatbot response function
def chatbot_response(user_input):
    input_text = vectorizer.transform([user_input])  # Convert input to TF-IDF
    predicted_intent = model.predict(input_text)[0]  # Predict intent
    
    # Find and return the correct response
    for intent in intents['intents']:
        if intent['tag'] == predicted_intent:
            return random.choice(intent['responses'])
    
    return "I'm not sure how to respond to that."

# Interactive chatbot loop
if __name__ == "__main__":
    print('Hello! I am a chatbot. Type "quit" to exit.')
    while True:
        user_input = input("> ")
        if user_input.lower() == "quit":
            break
        print(chatbot_response(user_input))
